// authentication.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private isAuthenticated = new BehaviorSubject<boolean>(false);

  constructor() {
    // Check if the user is already authenticated (e.g., from a stored token)
    this.checkAuthenticationStatus();
  }

  private checkAuthenticationStatus() {
    // Implement logic to check if the user is already authenticated (e.g., check for a stored token)
    const storedToken = localStorage.getItem('authToken');
    this.isAuthenticated.next(!!storedToken);
  }

  login() {
    // Implement your login logic here (e.g., request authentication from a server)
    // Once authenticated, set isAuthenticated to true
    this.isAuthenticated.next(true);
    // You might also store an authentication token in local storage
    const storage=localStorage.setItem('authToken', 'yourAuthToken');
    console.log('storage',storage);
  }

  logout() {
    // Implement your logout logic here (e.g., revoke authentication on the server)
    // Set isAuthenticated to false and remove the authentication token
    this.isAuthenticated.next(false);
    const storage=localStorage.removeItem('authToken');
    
    console.log('storage',storage);
  }

  isAuthenticatedObservable() {
    return this.isAuthenticated.asObservable();
  }
}
