import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {
  isAuthenticated: boolean | undefined;
  activeUsersCount: number = 0;
  registeredUsersCount: number = 0;
  totalUsersCount: number = 0;
  constructor(private authService: AuthenticationService,private router:Router,private platform: Platform) { }

  ngOnInit() {
    this.platform.backButton.subscribeWithPriority(10, () => {
      this.handleBackButton();
    });
   
  }
 
  logout() {
    // Call the logout method from the authentication service
    this.authService.logout();
    this.router.navigate(["/signin"])
  }

  handleBackButton() {
    // Check if it's the dashboard page
    if (this.router.url === '/dashboard') {
      if ((navigator as any)['app']) {
                  (navigator as any)['app'].exitApp(); // Exit the app
                 }
    } 
  }


  items = [
    { name: 'John Doe', time: '10:30 AM', image: 'path/to/john-doe.jpg' },
    { name: 'Jane Smith', time: '12:45 PM', image: 'path/to/jane-smith.jpg' },
    { name: 'Bob Johnson', time: '3:15 PM', image: 'path/to/bob-johnson.jpg' },
  ];
}
