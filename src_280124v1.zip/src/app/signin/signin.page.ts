import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from '../service/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.page.html',
  styleUrls: ['./signin.page.scss'],
})
export class SigninPage implements OnInit {
  loginForm: FormGroup;
  isAuthenticated: boolean | undefined;
 

  constructor(private navCtrl: NavController, private formBuilder: FormBuilder,private authService: AuthenticationService,private router:Router) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.authService.isAuthenticatedObservable().subscribe((isAuthenticated) => {
      this.isAuthenticated = isAuthenticated;
    });
    console.log('auth',this.isAuthenticated);
    if(this.isAuthenticated){
      this.router.navigate(["/dashboard"])
    }
    
  }
  login() {
    if (this.loginForm.valid) {
      // Perform authentication logic here
      // For simplicity, we'll just navigate to another page on successful login
      this.authService.login();
      this.navCtrl.navigateForward('/dashboard');
      
    } else {
      // Handle form validation errors (show error message, etc.)
      console.log('Invalid credentials');
    }
  }




}
